// Google Sheet > Extensions > Apps Script > এই কোড পেস্ট করুন > Deploy > New deployment > Web app
// Execute as: Me | Who has access: Anyone > Deploy > Web app URL কপি করে landing.html এর SHEET_URL এ বসান
function doPost(e) {
  var d = JSON.parse(e.postData.contents);
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('Orders') || ss.insertSheet('Orders');
  if (sh.getLastRow() === 0) sh.appendRow(['সময়','নাম','ফোন','ঠিকানা','কালার','পরিমাণ','এলাকা','ডেলিভারি চার্জ','মোট']);
  sh.appendRow([new Date(), d.name, "'" + d.phone, d.address, d.color, d.qty, d.area, d.shipping, d.total]);
  return ContentService.createTextOutput('ok');
}
