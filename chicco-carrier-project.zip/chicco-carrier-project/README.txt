Chicco Carrier – প্রজেক্ট ফাইল
================================
public_html/   -> এই ফোল্ডারের ৩টা ফাইল (index.html, video.mp4, video2.mp4) Hostinger-এর public_html-এ একসাথে আপলোড করুন। নাম বদলাবেন না।
media/         -> সাইটে ব্যবহৃত সব ছবি ও ভিডিও (প্রোডাক্ট, রিভিউ, লোগো, থাম্বনেইল)। ভবিষ্যতে দরকার হলে ব্যবহার করবেন, হোস্টিংয়ে আপলোড লাগবে না।
apps-script/   -> google-sheet-apps-script.gs: Google Sheet-এ অর্ডার সেভ করার কোড।

Google Sheet চালু করতে:
1. Sheet খুলুন > Extensions > Apps Script > কোড পেস্ট করুন > Deploy > New deployment > Web app (Execute as: Me, Access: Anyone)।
2. যে URL পাবেন, index.html ফাইলটা Hostinger File Manager-এ Edit করে var SHEET_URL="" এর ভেতরে বসান এবং Save করুন।

যোগাযোগ: 01540730012 | m.me/1076618728860187
